﻿//5kyu https://www.codewars.com/kata/56baeae7022c16dd7400086e

namespace CodeWars
{
    public static class PhoneDir
    {
        public static string Phone(string strng, string num)
        {
            return null;
        }
    }
}
